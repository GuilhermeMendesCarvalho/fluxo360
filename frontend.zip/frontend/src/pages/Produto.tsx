export default function Produto() {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 px-4">
        <h1 className="text-3xl font-bold text-indigo-600 mb-4">Página de Produtos</h1>
        <p className="text-gray-700 text-lg">Essa é uma rota protegida. Só acessa quem estiver logado.</p>
      </div>
    );
  }
  